# 🎬 Rahman Shorts - AI Video-to-Shorts Generator

**Turn any YouTube video or upload into viral 30-second shorts with AI-powered captions.**

Built with FFmpeg, OpenAI Whisper, FastAPI, and a dark premium UI.

---

## 🚀 Quick Start (Local)

```bash
# 1. Setup (installs deps, checks FFmpeg)
bash setup.sh

# 2. Start server
python3 backend_api.py

# 3. Open browser
open http://localhost:8000/static/
```

---

## ☁️ Deploy to AWS (FREE for 12 Months)

### Prerequisites
- AWS account (free tier eligible)
- AWS CLI installed: `brew install awscli` (Mac) or [download](https://aws.amazon.com/cli/)
- AWS credentials configured: `aws configure`

### One Command Deploy

```bash
bash deploy-aws.sh
```

**What it does:**
1. Creates EC2 t3.micro instance (free tier)
2. Assigns permanent Elastic IP
3. Sets up Security Group (SSH from your IP only)
4. Creates S3 bucket for clips
5. Installs Docker, FFmpeg, Python
6. Deploys your app
7. Starts the server

**Wait 5 minutes, then visit the URL it prints.**

### Manual Deploy (Learn AWS)

See `aws-cloudformation.yaml` for the full infrastructure template.

---

## 🐳 Docker Deploy

```bash
# Build and run
docker-compose up --build -d

# View logs
docker-compose logs -f

# Stop
docker-compose down
```

---

## 📁 Project Structure

```
rahman-shorts/
├── backend_api.py          # FastAPI backend (real video processing)
├── frontend/
│   └── index.html          # Complete SPA frontend
├── templates/
│   └── caption_templates.json  # 9 caption styles
├── requirements.txt        # Python dependencies
├── Dockerfile              # Docker image
├── docker-compose.yml      # Local Docker stack
├── setup.sh                # Local setup script
├── deploy-aws.sh           # AWS one-command deploy
├── aws-cloudformation.yaml # AWS infrastructure template
└── README.md               # This file
```

---

## ✨ Features

| Feature | Status |
|---------|--------|
| YouTube URL processing | ✅ Real (yt-dlp) |
| File upload (drag & drop) | ✅ Real |
| AI Transcription | ✅ Whisper API + Mock fallback |
| Viral moment detection | ✅ Real algorithm |
| Auto-reframe to 9:16 | ✅ Real FFmpeg |
| Caption burn-in | ✅ Real FFmpeg drawtext |
| 9 caption templates | ✅ Real styles |
| Clip download (MP4) | ✅ Real files |
| Clip editing | ✅ Real |
| Thumbnail generation | ✅ Real |
| Progress tracking | ✅ Real polling |

---

## 🔌 API Endpoints

| Endpoint | Method | Description |
|----------|--------|-------------|
| `/api/health` | GET | System health check |
| `/api/templates` | GET | List caption templates |
| `/api/process` | POST | Process YouTube URL |
| `/api/process-file` | POST | Upload & process video |
| `/api/status/{job_id}` | GET | Check job progress |
| `/api/download/{clip_id}` | GET | Download clip MP4 |
| `/api/thumbnail/{clip_id}` | GET | Get thumbnail |
| `/api/clip/{clip_id}/edit` | POST | Edit clip metadata |

---

## 🔧 Environment Variables

| Variable | Default | Description |
|----------|---------|-------------|
| `OPENAI_API_KEY` | - | Whisper API key (optional) |
| `HOST` | 0.0.0.0 | Server host |
| `PORT` | 8000 | Server port |
| `MAX_FILE_SIZE` | 2147483648 | Max upload (2GB) |
| `MAX_CLIPS` | 20 | Max clips per video |
| `MAX_CLIP_DURATION` | 60 | Max clip length (seconds) |
| `DEFAULT_CLIP_DURATION` | 30 | Default clip length |

---

## 💰 AWS Free Tier Limits

| Resource | Free Tier | After 12 Months |
|----------|-----------|-----------------|
| EC2 t3.micro | 750 hrs/month | ~$8.50/month |
| 30GB SSD | Included | ~$3.60/month |
| Elastic IP | Free (attached) | ~$3.60/month (if unattached) |
| S3 (5GB) | Included | ~$0.23/month |
| Data transfer (15GB) | Included | ~$0.09/GB |

**Total after free tier: ~$8.50/month** (if running 24/7)

**To stop charges:** Stop the EC2 instance or delete the CloudFormation stack.

---

## 🛠️ Troubleshooting

| Issue | Solution |
|-------|----------|
| "Connection refused" | Wait 2-3 more minutes for setup |
| "Permission denied (publickey)" | `chmod 400 rahman-shorts-key.pem` |
| "Out of memory" | Add swap: `sudo fallocate -l 1G /swapfile && sudo mkswap /swapfile && sudo swapon /swapfile` |
| "No space left" | `docker system prune -a` |
| Slow processing | t3.micro is small; upgrade to t3.small for $15/month |

---

## 📜 License

MIT — Build something amazing.
