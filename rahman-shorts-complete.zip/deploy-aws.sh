#!/bin/bash
# ═══════════════════════════════════════════════════════════════════════════════
#  RAHMAN SHORTS - AWS FREE TIER ONE-COMMAND DEPLOY
#  Run: bash deploy-aws.sh
#  Cost: $0 for 12 months
# ═══════════════════════════════════════════════════════════════════════════════

set -e

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
PURPLE='\033[0;35m'
CYAN='\033[0;36m'
NC='\033[0m'

STACK_NAME="rahman-shorts"
REGION="${AWS_REGION:-us-east-1}"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

echo ""
echo -e "${PURPLE}╔════════════════════════════════════════════════════════════════╗${NC}"
echo -e "${PURPLE}║     🎬 RAHMAN SHORTS - AWS FREE TIER DEPLOY                  ║${NC}"
echo -e "${PURPLE}║     💰 Cost: $0/month  |  ⏱️  Time: ~5 minutes               ║${NC}"
echo -e "${PURPLE}╚════════════════════════════════════════════════════════════════╝${NC}"
echo ""

# Check AWS CLI
if ! command -v aws &> /dev/null; then
    echo -e "${RED}❌ AWS CLI not installed${NC}"
    echo -e "${YELLOW}Install:${NC}"
    echo -e "  Mac: ${CYAN}brew install awscli${NC}"
    echo -e "  Linux: ${CYAN}curl "https://awscli.amazonaws.com/awscli-exe-linux-x86_64.zip" -o awscliv2.zip && unzip awscliv2.zip && sudo ./aws/install${NC}"
    exit 1
fi

if ! aws sts get-caller-identity &> /dev/null; then
    echo -e "${RED}❌ AWS not configured. Run: aws configure${NC}"
    exit 1
fi

ACCOUNT_ID=$(aws sts get-caller-identity --query Account --output text)
echo -e "${GREEN}✅ AWS Account: ${ACCOUNT_ID}${NC}"

# Get inputs
echo ""
read -p "🤖 OpenAI API Key (press Enter to skip): " OPENAI_KEY
MY_IP=$(curl -s https://checkip.amazonaws.com)
echo -e "${CYAN}🌍 Your IP: ${MY_IP}${NC}"

# Create key pair
KEY_NAME="rahman-shorts-key"
if ! aws ec2 describe-key-pairs --key-names "$KEY_NAME" --region "$REGION" &> /dev/null; then
    echo -e "${CYAN}Creating key pair...${NC}"
    aws ec2 create-key-pair --key-name "$KEY_NAME" --region "$REGION" --query 'KeyMaterial' --output text > "${SCRIPT_DIR}/${KEY_NAME}.pem"
    chmod 400 "${SCRIPT_DIR}/${KEY_NAME}.pem"
    echo -e "${GREEN}✅ Key saved: ${KEY_NAME}.pem${NC}"
else
    echo -e "${GREEN}✅ Using existing key${NC}"
fi

# Create S3 bucket for deployment
S3_BUCKET="rahman-shorts-deploy-${ACCOUNT_ID}-${REGION}"
if ! aws s3 ls "s3://${S3_BUCKET}" --region "$REGION" &> /dev/null; then
    aws s3 mb "s3://${S3_BUCKET}" --region "$REGION"
fi

# Upload app
echo -e "${CYAN}📦 Uploading app...${NC}"
cd "$SCRIPT_DIR"
zip -q -r /tmp/rahman-shorts.zip . -x "*.git*" -x "*/__pycache__/*" -x "*.pyc" -x "*.pem" -x "uploads/*" -x "clips/*" -x "temp/*"
aws s3 cp /tmp/rahman-shorts.zip "s3://${S3_BUCKET}/app.zip" --region "$REGION"

# Deploy CloudFormation
echo -e "${BLUE}🚀 Creating infrastructure...${NC}"

if aws cloudformation describe-stacks --stack-name "$STACK_NAME" --region "$REGION" &> /dev/null; then
    echo -e "${YELLOW}Deleting old stack...${NC}"
    aws cloudformation delete-stack --stack-name "$STACK_NAME" --region "$REGION"
    aws cloudformation wait stack-delete-complete --stack-name "$STACK_NAME" --region "$REGION" 2>/dev/null || true
fi

aws cloudformation create-stack \
    --stack-name "$STACK_NAME" \
    --template-body "file://${SCRIPT_DIR}/aws-cloudformation.yaml" \
    --parameters \
        ParameterKey=KeyPairName,ParameterValue="$KEY_NAME" \
        ParameterKey=OpenAIApiKey,ParameterValue="$OPENAI_KEY" \
        ParameterKey=YourIP,ParameterValue="${MY_IP}/32" \
    --capabilities CAPABILITY_IAM \
    --region "$REGION" \
    --tags Key=Project,Value=RahmanShorts

echo -e "${YELLOW}⏳ Waiting for infrastructure (3-4 min)...${NC}"
aws cloudformation wait stack-create-complete --stack-name "$STACK_NAME" --region "$REGION"

# Get outputs
SERVER_IP=$(aws cloudformation describe-stacks --stack-name "$STACK_NAME" --region "$REGION" --query 'Stacks[0].Outputs[?OutputKey==`ServerIP`].OutputValue' --output text)
API_URL=$(aws cloudformation describe-stacks --stack-name "$STACK_NAME" --region "$REGION" --query 'Stacks[0].Outputs[?OutputKey==`APIURL`].OutputValue' --output text)
FRONTEND_URL=$(aws cloudformation describe-stacks --stack-name "$STACK_NAME" --region "$REGION" --query 'Stacks[0].Outputs[?OutputKey==`FrontendURL`].OutputValue' --output text)
S3_CLIPS=$(aws cloudformation describe-stacks --stack-name "$STACK_NAME" --region "$REGION" --query 'Stacks[0].Outputs[?OutputKey==`S3Bucket`].OutputValue' --output text)

# Setup server
echo ""
echo -e "${BLUE}🔧 Installing app on server...${NC}"

# Wait for SSH
for i in {1..30}; do
    if nc -z "$SERVER_IP" 22 2>/dev/null; then break; fi
    echo -e "  Waiting for SSH... ($i/30)"
    sleep 10
done

sleep 30

# Copy and run setup
scp -o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null -i "${SCRIPT_DIR}/${KEY_NAME}.pem" \
    /tmp/rahman-shorts.zip "ubuntu@${SERVER_IP}:/tmp/app.zip"

ssh -o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null -i "${SCRIPT_DIR}/${KEY_NAME}.pem" \
    "ubuntu@${SERVER_IP}" << EOF
    cd /opt/rahman-shorts
    unzip -o /tmp/app.zip
    echo "OPENAI_API_KEY=${OPENAI_KEY}" > .env
    echo "HOST=0.0.0.0" >> .env
    echo "PORT=8000" >> .env
    pip3 install -r requirements.txt
    docker-compose up -d
EOF

# Done
echo ""
echo -e "${PURPLE}════════════════════════════════════════════════════════════════${NC}"
echo -e "${PURPLE}  🎉 RAHMAN SHORTS IS LIVE!${NC}"
echo -e "${PURPLE}════════════════════════════════════════════════════════════════${NC}"
echo ""
echo -e "${CYAN}🌐 API:${NC}        ${GREEN}${API_URL}${NC}"
echo -e "${CYAN}🎨 Frontend:${NC}   ${GREEN}${FRONTEND_URL}${NC}"
echo -e "${CYAN}🖥️  Server IP:${NC} ${GREEN}${SERVER_IP}${NC}"
echo ""
echo -e "${YELLOW}SSH:${NC}  ssh -i ${KEY_NAME}.pem ubuntu@${SERVER_IP}"
echo -e "${YELLOW}Logs:${NC} ssh -i ${KEY_NAME}.pem ubuntu@${SERVER_IP} "sudo tail -f /var/log/rahman-shorts-setup.log""
echo ""
echo -e "${PURPLE}🚀 OPEN ${FRONTEND_URL} IN YOUR BROWSER!${NC}"
echo ""

cat > "${SCRIPT_DIR}/DEPLOYMENT-INFO.txt" << EOF
Rahman Shorts Deployment
========================
Date: $(date)
API: ${API_URL}
Frontend: ${FRONTEND_URL}
Server IP: ${SERVER_IP}
SSH: ssh -i ${KEY_NAME}.pem ubuntu@${SERVER_IP}
Delete: aws cloudformation delete-stack --stack-name ${STACK_NAME} --region ${REGION}
EOF
