#!/bin/bash
# Rahman Shorts - Local Setup

echo "🎬 Setting up Rahman Shorts..."

# Check Python
if ! command -v python3 &> /dev/null; then
    echo "❌ Python 3 not found. Please install Python 3.11+"
    exit 1
fi

# Check FFmpeg
if ! command -v ffmpeg &> /dev/null; then
    echo "📥 Installing FFmpeg..."
    if [[ "$OSTYPE" == "darwin"* ]]; then
        brew install ffmpeg
    elif [[ "$OSTYPE" == "linux-gnu"* ]]; then
        sudo apt-get update && sudo apt-get install -y ffmpeg
    else
        echo "Please install FFmpeg manually: https://ffmpeg.org/download.html"
        exit 1
    fi
fi

# Check yt-dlp
if ! command -v yt-dlp &> /dev/null; then
    echo "📥 Installing yt-dlp..."
    pip3 install yt-dlp
fi

# Install Python deps
echo "📦 Installing Python dependencies..."
pip3 install -r requirements.txt

# Create directories
mkdir -p uploads clips temp

echo ""
echo "✅ Setup complete!"
echo ""
echo "🚀 To start the server:"
echo "   python3 backend_api.py"
echo ""
echo "🌐 Then open: http://localhost:8000/static/"
echo ""
echo "🔧 Optional: Set OpenAI API key for real transcription:"
echo "   export OPENAI_API_KEY=sk-..."
